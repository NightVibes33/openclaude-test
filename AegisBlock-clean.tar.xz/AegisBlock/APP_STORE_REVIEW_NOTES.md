# App Review Notes — AegisBlock

AegisBlock is a content-blocking/privacy utility. It does **not** provide a remote VPN service and does not operate VPN exit servers.

## Network Extension behavior

- The `NEPacketTunnelProvider` is used only to receive DNS packets addressed to AegisBlock's synthetic local resolver addresses (`198.18.0.2` and `fd00::2`).
- The tunnel installs only host routes for those two DNS addresses. Ordinary application traffic is not routed through the tunnel.
- Blocklist matching is performed locally on the device against a memory-mapped compiled domain index.
- Allowed DNS messages are forwarded over DNS-over-HTTPS directly to the resolver selected by the user (Cloudflare or Quad9).
- AegisBlock has no remote VPN gateway, proxy, account system, analytics SDK, advertising SDK, or developer-operated DNS service.

## User disclosure

Before the protection UI is available, the first-run screen states:

1. Filtering happens on device.
2. The Network Extension carries DNS only, not ordinary web/application traffic.
3. AegisBlock collects no analytics/account data; allowed DNS queries are sent only to the selected resolver.

The iOS VPN-configuration prompt appears only after the user explicitly enables device-wide DNS protection.

## Safari

The app embeds five Safari Content Blocker extensions plus one Safari Web Extension. Safari extensions must be enabled by the user in system Safari extension settings.

## Privacy

`PrivacyInfo.xcprivacy` declares no tracking and no collected data. App Group `UserDefaults` access uses required-reason code `1C8F.1` for app/extension shared settings.
