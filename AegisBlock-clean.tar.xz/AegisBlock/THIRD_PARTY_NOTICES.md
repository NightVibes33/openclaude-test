# Third-party notices

## just-an-adblocker

Several low-level DNS packet-processing patterns in AegisBlock are adapted from `AlmoutasemNabil/just-an-adblocker`, licensed under the MIT License.

Copyright (c) the just-an-adblocker contributors.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the conditions in the upstream MIT license.

Upstream: https://github.com/AlmoutasemNabil/just-an-adblocker

## Filter lists

AegisBlock does not bundle third-party filter lists in the application binary. It downloads user-enabled lists directly from their publishers at runtime. Each list remains subject to its publisher's license and terms. The default source definitions currently include OISD, HaGeZi, AdGuard DNS Filter, and StevenBlack Hosts.

Safari precompiled WebKit rules are downloaded at runtime from `bnema/ublock-webkit-filters`; that project's source code is GPL-3.0. AegisBlock does not incorporate that converter's source code into the app.
