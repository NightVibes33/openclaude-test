(async () => {
  'use strict';
  try {
    const native = await browser.runtime.sendNativeMessage({host: location.hostname});
    if (native?.allowed) return;
  } catch {}

  const params = new Set(['fbclid','gclid','dclid','msclkid','igshid','mc_cid','mc_eid','ref_src','yclid']);
  const clean = raw => {
    try {
      const u = new URL(raw, location.href);
      let changed = false;
      for (const key of [...u.searchParams.keys()]) {
        if (params.has(key) || key.startsWith('utm_')) { u.searchParams.delete(key); changed = true; }
      }
      return changed ? u.href : raw;
    } catch { return raw; }
  };
  document.addEventListener('click', event => {
    const a = event.target?.closest?.('a[href]');
    if (a) a.href = clean(a.href);
  }, true);

  const selectors = [
    'ins.adsbygoogle', '[id^="google_ads_"]', '[data-ad-slot]',
    '.ad-banner', '.adsbox', '.advertisement', '.sponsored-ad',
    '[aria-label="Advertisement"]', '[aria-label="Sponsored"]'
  ];
  const sweep = root => {
    if (!root?.querySelectorAll) return;
    for (const el of root.querySelectorAll(selectors.join(','))) {
      const rect = el.getBoundingClientRect();
      if (rect.width > 1 || rect.height > 1) el.style.setProperty('display','none','important');
    }
  };
  const start = () => {
    sweep(document);
    new MutationObserver(records => {
      for (const record of records) for (const node of record.addedNodes) if (node.nodeType === 1) sweep(node);
    }).observe(document.documentElement, {subtree:true, childList:true});
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true}); else start();
})();
