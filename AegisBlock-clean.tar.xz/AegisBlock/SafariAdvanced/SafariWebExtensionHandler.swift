import Foundation
import SafariServices

final class SafariWebExtensionHandler: NSObject, NSExtensionRequestHandling {
  func beginRequest(with context: NSExtensionContext) {
    let item = context.inputItems.first as? NSExtensionItem
    let message = item?.userInfo?[SFExtensionMessageKey] as? [String: Any]
    let host = (message?["host"] as? String)?.lowercased() ?? ""
    let allowed = isAllowed(host: host)
    let response = NSExtensionItem()
    response.userInfo = [SFExtensionMessageKey: ["ok": true, "allowed": allowed]]
    context.completeRequest(returningItems: [response], completionHandler: nil)
  }

  private func isAllowed(host: String) -> Bool {
    guard !host.isEmpty,
      let group = resolvedAppGroupID(),
      let root = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group),
      let data = try? Data(contentsOf: root.appendingPathComponent("filters.json")),
      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
      let list = json["userAllowlist"] as? [String]
    else { return false }
    return list.contains { domain in host == domain || host.hasSuffix("." + domain) }
  }

  private func resolvedAppGroupID() -> String? {
    var candidates: [String] = []
    if var parentID = Bundle.main.bundleIdentifier {
      if parentID.hasSuffix(".advanced") { parentID.removeLast(".advanced".count) }
      candidates.append("group.\(parentID)")
    }
    if let configured = Bundle.main.object(forInfoDictionaryKey: "AppGroupID") as? String,
      !configured.isEmpty, !candidates.contains(configured)
    {
      candidates.append(configured)
    }
    return candidates.first {
      FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: $0) != nil
    }
  }
}
