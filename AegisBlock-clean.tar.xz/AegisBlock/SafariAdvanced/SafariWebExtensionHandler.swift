import Foundation
import SafariServices

final class SafariWebExtensionHandler: NSObject, NSExtensionRequestHandling {
  func beginRequest(with context: NSExtensionContext) {
    let item = context.inputItems.first as? NSExtensionItem
    let message = item?.userInfo?[SFExtensionMessageKey] as? [String: Any]
    let host = (message?["host"] as? String)?.lowercased() ?? ""
    let allowed = isAllowed(host: host)
    let response = NSExtensionItem()
    response.userInfo = [SFExtensionMessageKey: ["ok": true, "allowed": allowed]]
    context.completeRequest(returningItems: [response], completionHandler: nil)
  }

  private func isAllowed(host: String) -> Bool {
    guard !host.isEmpty,
      let group = Bundle.main.object(forInfoDictionaryKey: "AppGroupID") as? String,
      let root = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group),
      let data = try? Data(contentsOf: root.appendingPathComponent("filters.json")),
      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
      let list = json["userAllowlist"] as? [String]
    else { return false }
    return list.contains { domain in host == domain || host.hasSuffix("." + domain) }
  }
}
