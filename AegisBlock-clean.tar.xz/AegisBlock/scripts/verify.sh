#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/Packages/AegisCore"
swift test
cd "$ROOT"
swiftc -frontend -parse App/*.swift PacketTunnel/*.swift SafariBlocker/*.swift SafariAdvanced/*.swift Widgets/*.swift
python3 - <<'PY'
import plistlib, glob
from pathlib import Path
for f in glob.glob('Config/*.plist') + glob.glob('Config/*.entitlements') + ['Shared/PrivacyInfo.xcprivacy']:
    plistlib.loads(Path(f).read_bytes())
print('plist validation: OK')
PY
