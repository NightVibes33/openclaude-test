# Verification status

Local verification completed on 2026-10-03 with Swift 6.2.1 on Linux.

Passed:

- AegisCore builds in Swift 6 mode.
- 5 Swift Testing tests pass: filter formats, mmap blocklist, suffix matching, DNS sink response, compressed CNAME alias inspection.
- Every Swift file in the app, packet tunnel, Safari extensions, widget, and core parses successfully.
- Every Info.plist, entitlements plist, and `PrivacyInfo.xcprivacy` parses successfully.
- `project.yml` contains all 9 expected targets and is valid YAML.

The Linux environment cannot type-check Apple-only frameworks or execute `xcodebuild`. The included GitHub Actions CI uses GitHub's `xcode-27` macOS runner, installs XcodeGen, generates `AegisBlock.xcodeproj`, and performs the authoritative iOS Simulator build. The `Unsigned IPA` workflow performs the device Release build and packages the resulting `.app` as an unsigned IPA artifact.
