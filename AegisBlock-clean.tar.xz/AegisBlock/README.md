# AegisBlock for iOS

A privacy-first iOS ad blocker that combines **Safari-native content blocking** with a **DNS-only Network Extension** for app-wide ad/tracker blocking.

## Protection stack

- **5 Safari Content Blocker extensions** for high-capacity WebKit rule shards.
- **Safari Web Extension** for safe cosmetic cleanup and tracking-parameter stripping that declarative rules cannot express.
- **DNS-only `NEPacketTunnelProvider`** for ads and trackers inside apps without routing ordinary app traffic through a remote VPN.
- **Encrypted upstream DNS-over-HTTPS** with IP-literal Cloudflare and Quad9 presets to avoid tunnel bootstrap recursion.
- **Memory-mapped compiled domain index** so the tunnel does not materialize huge filter sets in extension memory.
- **CNAME/DNAME/SVCB/HTTPS alias inspection** to block DNS cloaking when a first-party-looking hostname resolves through a listed tracker.
- **User allowlist and denylist** shared by Safari and DNS filtering.
- **Background app refresh + BGProcessing rule maintenance**, Shortcuts/App Intents, and a status widget.
- **No analytics, no account, no ad SDK, no tracking SDK.**

## Why a packet tunnel instead of a DNS Proxy extension?

Apple restricts `NEDNSProxyProvider` deployment on iOS to supervised or managed-device scenarios. A destination-only packet tunnel works on ordinary consumer iPhones and lets AegisBlock capture only traffic addressed to its synthetic DNS resolver. Normal web/app traffic stays on the physical interface.

## Architecture

```text
AegisBlock.app
├── SwiftUI app
├── AegisCore (pure Swift, Linux-testable)
│   ├── blocklist parser/compiler
│   ├── mmap sorted hash index
│   ├── DNS wire parser/response builder
│   └── IPv4/IPv6 UDP packet path
├── AegisTunnel.appex
│   └── DNS-only packet tunnel + DoH forwarding
├── AegisBlocker1…5.appex
│   └── Safari Content Blocker shards
├── AegisAdvanced.appex
│   └── Safari Web Extension
└── AegisWidgets.appex
```

## Build without a Mac

The repo includes GitHub Actions workflows using the `xcode-27` hosted runner.

1. Push the repository to GitHub.
2. Run **CI** to validate Swift core tests and an unsigned Simulator build.
3. Run **Unsigned IPA** to produce `AegisBlock-unsigned.ipa` as a workflow artifact.
4. For App Store/TestFlight, configure your Apple team/signing in Xcode/App Store Connect and archive with distribution signing.

The project is generated from `project.yml` with XcodeGen, so no generated `.xcodeproj` is committed.

## First run

1. Open AegisBlock and tap **Update all filters**.
2. Tap the shield and approve the iOS VPN configuration.
3. In iOS Safari extension settings, enable **AegisBlock 1–5** and **AegisBlock Advanced**.
4. Keep the default resolver or select another encrypted DNS provider in Settings.

## Important platform limits

AegisBlock does **not** perform HTTPS man-in-the-middle interception. DNS filtering cannot remove an ad served from the exact same hostname/path as desired first-party content, and apps that intentionally bypass system DNS can evade DNS-only filtering. Safari's native content blockers cover the web side of those gaps without decrypting browsing traffic.

## Privacy manifest

The app declares no collected data and no tracking. A first-run disclosure explains the DNS-only Network Extension before the user can enable protection. Shared `UserDefaults` usage across the app group is declared with Apple's `1C8F.1` required-reason code.

## Verification

```bash
./scripts/verify.sh
```

This runs the Swift 6.2 core tests, parses every Swift source file, and validates all plist/entitlement/privacy-manifest files.
