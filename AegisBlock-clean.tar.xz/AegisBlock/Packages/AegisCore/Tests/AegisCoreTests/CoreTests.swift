import Foundation
import Testing

@testable import AegisCore

@Test func filterParserHandlesCommonFormats() {
  let parsed = FilterListParser.parse(
    """
    ||ads.example.com^
    @@||good.example.com^
    0.0.0.0 tracker.example.net
    bare.example.org
    example.com##.ad
    """)
  #expect(parsed.blockDomains.contains("ads.example.com"))
  #expect(parsed.blockDomains.contains("tracker.example.net"))
  #expect(parsed.blockDomains.contains("bare.example.org"))
  #expect(parsed.allowDomains == ["good.example.com"])
}

@Test func compiledBlocklistRoundTrip() throws {
  let url = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(UUID().uuidString)
  defer { try? FileManager.default.removeItem(at: url) }
  let hashes = [FNV1a.hash64("ads.example.com"), FNV1a.hash64("tracker.example.net")]
  try CompiledBlocklist.write(hashes: hashes, generation: 7, to: url)
  let view = try CompiledBlocklistView(contentsOf: url)
  #expect(view.count == 2)
  #expect(view.generation == 7)
  #expect(view.contains(hashes[0]))
}

@Test func domainMatcherUsesParentSuffix() throws {
  let url = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(UUID().uuidString)
  defer { try? FileManager.default.removeItem(at: url) }
  try CompiledBlocklist.write(hashes: [FNV1a.hash64("ads.example.com")], generation: 1, to: url)
  let matcher = DomainMatcher(blocklist: try CompiledBlocklistView(contentsOf: url))
  #expect(matcher.verdict(for: "x.ads.example.com") == .block)
  #expect(matcher.verdict(for: "example.com") == .none)
}

@Test func dnsBlockedResponsePreservesTransactionID() throws {
  let query = Data([
    0x12, 0x34, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0, 3, 97, 100, 115, 7, 101, 120, 97, 109, 112, 108,
    101, 3, 99, 111, 109, 0, 0, 1, 0, 1,
  ])
  let q = try DNSParser.parseQuery(query)
  let response = [UInt8](DNSResponseBuilder.blocked(for: q))
  #expect(response[0] == 0x12 && response[1] == 0x34)
  #expect(response[2] & 0x80 != 0)
}

@Test func dnsResponseInspectorFindsCompressedCNAME() {
  let response = Data([
    0x12, 0x34, 0x81, 0x80, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
    0x03, 0x77, 0x77, 0x77, 0x07, 0x65, 0x78, 0x61, 0x6d, 0x70, 0x6c, 0x65, 0x03, 0x63, 0x6f, 0x6d,
    0x00, 0x00, 0x01, 0x00, 0x01,
    0xc0, 0x0c, 0x00, 0x05, 0x00, 0x01, 0x00, 0x00, 0x00, 0x3c, 0x00, 0x0a,
    0x07, 0x74, 0x72, 0x61, 0x63, 0x6b, 0x65, 0x72, 0xc0, 0x10,
  ])
  #expect(DNSResponseInspector.aliasTargets(in: response) == ["tracker.example.com"])
}

@Test func runtimeIdentityTracksSideloadedBundleFamily() {
  let app = "com.nightvibes33.aegisblock.39A8Q3T3TR"
  #expect(RuntimeIdentity.parentApplicationBundleID(from: app) == app)
  #expect(RuntimeIdentity.parentApplicationBundleID(from: app + ".tunnel") == app)
  #expect(RuntimeIdentity.parentApplicationBundleID(from: app + ".blocker5") == app)
  #expect(RuntimeIdentity.parentApplicationBundleID(from: app + ".advanced") == app)
  #expect(RuntimeIdentity.parentApplicationBundleID(from: app + ".widgets") == app)
}
