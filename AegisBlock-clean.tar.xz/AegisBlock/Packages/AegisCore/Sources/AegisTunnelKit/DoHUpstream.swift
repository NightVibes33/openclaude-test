import AegisCore
import Foundation

#if canImport(FoundationNetworking)
  import FoundationNetworking
#endif

public final class DoHUpstream: DNSUpstream, @unchecked Sendable {
  private let url: URL
  private let session: URLSession
  public init(url: URL, timeout: TimeInterval = 4) {
    self.url = url
    let c = URLSessionConfiguration.ephemeral
    c.timeoutIntervalForRequest = timeout
    c.timeoutIntervalForResource = timeout * 2
    c.httpAdditionalHeaders = [
      "Accept": "application/dns-message", "Content-Type": "application/dns-message",
    ]
    self.session = URLSession(configuration: c)
  }
  public func resolve(_ query: Data) async throws -> Data {
    var r = URLRequest(url: url)
    r.httpMethod = "POST"
    r.httpBody = query
    let (d, response) = try await session.data(for: r)
    guard let h = response as? HTTPURLResponse, h.statusCode == 200, d.count >= 12 else {
      throw UpstreamError.badResponse
    }
    return d
  }
}
