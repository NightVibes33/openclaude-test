import Foundation

public enum FNV1a {
  public static func hash64<S: StringProtocol>(_ string: S) -> UInt64 {
    var hash: UInt64 = 0xcbf2_9ce4_8422_2325
    for byte in string.utf8 {
      hash = (hash ^ UInt64(byte)) &* 0x100_0000_01b3
    }
    return hash
  }
}
