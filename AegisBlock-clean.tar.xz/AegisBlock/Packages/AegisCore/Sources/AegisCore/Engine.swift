import Foundation

public protocol DNSUpstream: Sendable { func resolve(_ query: Data) async throws -> Data }
public enum UpstreamError: Error, Equatable {
  case timeout, badResponse
  case connectionFailed(String)
}

public struct TunnelRuntimeStats: Codable, Sendable, Equatable {
  public var startedAt: Date
  public var totalQueries: UInt64
  public var blockedQueries: UInt64
  public var blocklistEntryCount: UInt64
  public init(
    startedAt: Date, totalQueries: UInt64, blockedQueries: UInt64, blocklistEntryCount: UInt64
  ) {
    self.startedAt = startedAt
    self.totalQueries = totalQueries
    self.blockedQueries = blockedQueries
    self.blocklistEntryCount = blocklistEntryCount
  }
}

public actor DNSProxyEngine {
  private var matcher: DomainMatcher
  private var upstream: any DNSUpstream
  private var total: UInt64 = 0
  private var blocked: UInt64 = 0
  private let started = Date()
  private var inFlight = 0
  private let maxInFlight: Int
  private let mtu: Int
  private var pausedUntil: Date?

  public init(
    matcher: DomainMatcher, upstream: any DNSUpstream, maxInFlight: Int = 256, mtu: Int = 1500
  ) {
    self.matcher = matcher
    self.upstream = upstream
    self.maxInFlight = maxInFlight
    self.mtu = mtu
  }

  public func handlePacket(_ packet: Data) async -> Data? {
    guard let udp = PacketParser.parseUDP(packet), udp.destinationPort == 53 else { return nil }
    let raw = Data(udp.payload)
    let query = try? DNSParser.parseQuery(raw)
    if query != nil { total &+= 1 }

    if let query, !isPaused {
      let verdict = matcher.verdict(for: query.questionName)
      if verdict == .block {
        blocked &+= 1
        return UDPReplyBuilder.reply(
          to: udp, payload: [UInt8](DNSResponseBuilder.blocked(for: query)))
      }
      return await forward(raw: raw, query: query, originalVerdict: verdict, udp: udp)
    }

    // Unsupported or unusual DNS messages should still resolve rather than
    // being black-holed. They simply bypass policy inspection.
    return await forward(raw: raw, query: query, originalVerdict: .none, udp: udp)
  }

  private func forward(raw: Data, query: DNSQuery?, originalVerdict: Verdict, udp: ParsedUDPPacket)
    async -> Data?
  {
    guard inFlight < maxInFlight else {
      guard let query else { return nil }
      return UDPReplyBuilder.reply(
        to: udp, payload: [UInt8](DNSResponseBuilder.servfail(for: query)))
    }

    inFlight += 1
    defer { inFlight -= 1 }

    do {
      let answer = try await upstream.resolve(raw)

      // Respect an explicit user allow for the queried name. Otherwise,
      // block responses that alias through a domain on the local list.
      if let query, !isPaused, originalVerdict != .allow {
        let cloaked = DNSResponseInspector.aliasTargets(in: answer).contains {
          matcher.verdict(for: $0) == .block
        }
        if cloaked {
          blocked &+= 1
          return UDPReplyBuilder.reply(
            to: udp, payload: [UInt8](DNSResponseBuilder.blocked(for: query)))
        }
      }

      let overhead = udp.ipVersion == 4 ? 28 : 48
      if answer.count + overhead > mtu {
        guard let query else { return nil }
        return UDPReplyBuilder.reply(
          to: udp, payload: [UInt8](DNSResponseBuilder.truncated(for: query)))
      }
      return UDPReplyBuilder.reply(to: udp, payload: [UInt8](answer))
    } catch {
      guard let query else { return nil }
      return UDPReplyBuilder.reply(
        to: udp, payload: [UInt8](DNSResponseBuilder.servfail(for: query)))
    }
  }

  public func reload(_ matcher: DomainMatcher) { self.matcher = matcher }
  public func setUpstream(_ upstream: any DNSUpstream) { self.upstream = upstream }
  public func pause(until: Date?) { pausedUntil = until }
  private var isPaused: Bool { (pausedUntil ?? .distantPast) > Date() }
  public func stats() -> TunnelRuntimeStats {
    .init(
      startedAt: started, totalQueries: total, blockedQueries: blocked,
      blocklistEntryCount: UInt64(matcher.blockedEntryCount))
  }
}
