import Foundation

public struct AppGroupPaths: Sendable {
  public let containerURL: URL
  public init(containerURL: URL) { self.containerURL = containerURL }

  #if canImport(Darwin)
    public init?(groupID: String) {
      guard
        let url = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: groupID)
      else { return nil }
      self.containerURL = url
    }
    public static func groupID(from bundle: Bundle) -> String? {
      bundle.object(forInfoDictionaryKey: "AppGroupID") as? String
    }
  #endif

  public var blocklistURL: URL { containerURL.appendingPathComponent("dns-blocklist.bin") }
  public var allowlistURL: URL { containerURL.appendingPathComponent("dns-allowlist.bin") }
  public var denylistURL: URL { containerURL.appendingPathComponent("dns-denylist.bin") }
  public var stateURL: URL { containerURL.appendingPathComponent("filters.json") }
  public var listsDirectory: URL { containerURL.appendingPathComponent("lists", isDirectory: true) }
  public var safariDirectory: URL {
    containerURL.appendingPathComponent("safari", isDirectory: true)
  }
  public var statsURL: URL { containerURL.appendingPathComponent("stats.json") }

  public func cachedListURL(sourceID: String) -> URL {
    listsDirectory.appendingPathComponent(sourceID + ".txt")
  }
  public func safariShardURL(index: Int) -> URL {
    safariDirectory.appendingPathComponent("shard-\(index).json")
  }

  public func ensureDirectories() throws {
    try FileManager.default.createDirectory(at: listsDirectory, withIntermediateDirectories: true)
    try FileManager.default.createDirectory(at: safariDirectory, withIntermediateDirectories: true)
  }
}
