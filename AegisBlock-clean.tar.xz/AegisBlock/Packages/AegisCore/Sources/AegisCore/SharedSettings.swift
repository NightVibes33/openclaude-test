import Foundation

public struct UpstreamConfig: Codable, Sendable, Hashable, Identifiable {
  public var id: String { name }
  public var name: String
  public var url: URL
  public init(name: String, url: URL) {
    self.name = name
    self.url = url
  }
  public static let cloudflare = UpstreamConfig(
    name: "Cloudflare", url: URL(string: "https://1.1.1.1/dns-query")!)
  public static let quad9 = UpstreamConfig(
    name: "Quad9", url: URL(string: "https://9.9.9.9/dns-query")!)
  // Keep tunnel upstreams IP-literal to avoid recursive bootstrap through the
  // tunnel's own DNS route. Google DoH redirects its IP endpoint to dns.google,
  // so it is intentionally not exposed here.
  public static let presets = [cloudflare, quad9]
}

public struct SharedSettings: @unchecked Sendable {
  private let defaults: UserDefaults
  public init(defaults: UserDefaults) { self.defaults = defaults }
  #if canImport(Darwin)
    public init?(groupID: String) {
      guard let d = UserDefaults(suiteName: groupID) else { return nil }
      self.defaults = d
    }
  #endif
  public var upstream: UpstreamConfig {
    get {
      guard let d = defaults.data(forKey: "upstream"),
        let x = try? JSONDecoder().decode(UpstreamConfig.self, from: d)
      else { return .quad9 }
      return x
    }
    nonmutating set {
      if let d = try? JSONEncoder().encode(newValue) { defaults.set(d, forKey: "upstream") }
    }
  }
  public var protectionActive: Bool {
    get { defaults.bool(forKey: "protectionActive") }
    nonmutating set { defaults.set(newValue, forKey: "protectionActive") }
  }
  public var onboardingComplete: Bool {
    get { defaults.bool(forKey: "onboardingComplete") }
    nonmutating set { defaults.set(newValue, forKey: "onboardingComplete") }
  }
  public var pausedUntil: Date? {
    get {
      let t = defaults.double(forKey: "pausedUntil")
      return t > Date().timeIntervalSince1970 ? Date(timeIntervalSince1970: t) : nil
    }
    nonmutating set { defaults.set(newValue?.timeIntervalSince1970 ?? 0, forKey: "pausedUntil") }
  }
  public var lastDNSUpdate: Date? {
    get { defaults.object(forKey: "lastDNSUpdate") as? Date }
    nonmutating set { defaults.set(newValue, forKey: "lastDNSUpdate") }
  }
  public var lastSafariUpdate: Date? {
    get { defaults.object(forKey: "lastSafariUpdate") as? Date }
    nonmutating set { defaults.set(newValue, forKey: "lastSafariUpdate") }
  }
}

public enum TunnelConstants {
  public static let tunnelIPv4 = "198.18.0.1", dnsIPv4 = "198.18.0.2", maskIPv4 = "255.255.255.0"
  public static let tunnelIPv6 = "fd00::1", dnsIPv6 = "fd00::2"
  public static let prefixIPv6 = 64
  public static let mtu = 1500
  public static let serverDescription = "AegisBlock • On-device DNS"
}

public enum TunnelRequest: Codable, Sendable {
  case ping, reloadRules, getStats
  case setPause(Date?)
  case setUpstream(UpstreamConfig)
}
public enum TunnelResponse: Codable, Sendable {
  case ok
  case stats(TunnelRuntimeStats)
  case failure(String)
}
public enum TunnelIPC {
  public static func encode(_ x: TunnelRequest) throws -> Data { try JSONEncoder().encode(x) }
  public static func decodeRequest(_ d: Data) throws -> TunnelRequest {
    try JSONDecoder().decode(TunnelRequest.self, from: d)
  }
  public static func encode(_ x: TunnelResponse) throws -> Data { try JSONEncoder().encode(x) }
  public static func decodeResponse(_ d: Data) throws -> TunnelResponse {
    try JSONDecoder().decode(TunnelResponse.self, from: d)
  }
}
