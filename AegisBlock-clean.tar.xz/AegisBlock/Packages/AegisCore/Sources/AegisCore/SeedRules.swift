import Foundation

public enum SeedRules {
  public static let domains = [
    "doubleclick.net", "googlesyndication.com", "googleadservices.com", "admob.com",
    "adservice.google.com", "googletagservices.com", "app-measurement.com", "google-analytics.com",
    "applovin.com", "vungle.com", "chartboost.com", "inmobi.com", "supersonicads.com",
    "adcolony.com", "smaato.net", "pubmatic.com", "adsrvr.org", "adnxs.com",
  ]
  public static let hashes = Set(domains.map(FNV1a.hash64))
}
