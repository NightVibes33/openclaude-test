import Foundation

public enum Verdict: Sendable, Equatable { case allow, block, none }

public struct DomainMatcher: @unchecked Sendable {
  public let blocklist: CompiledBlocklistView?
  public let allowlist: CompiledBlocklistView?
  public let denylist: CompiledBlocklistView?
  public init(
    blocklist: CompiledBlocklistView?, allowlist: CompiledBlocklistView? = nil,
    denylist: CompiledBlocklistView? = nil
  ) {
    self.blocklist = blocklist
    self.allowlist = allowlist
    self.denylist = denylist
  }

  public func verdict(for raw: String) -> Verdict {
    guard let domain = DomainValidator.normalize(raw) else { return .none }
    let suffixes = DomainValidator.suffixes(of: domain)
    if suffixes.contains(where: { allowlist?.contains(FNV1a.hash64($0)) == true }) { return .allow }
    if suffixes.contains(where: { denylist?.contains(FNV1a.hash64($0)) == true }) { return .block }
    if suffixes.contains(where: { blocklist?.contains(FNV1a.hash64($0)) == true }) { return .block }
    return .none
  }

  public var blockedEntryCount: Int { blocklist?.count ?? 0 }
}
