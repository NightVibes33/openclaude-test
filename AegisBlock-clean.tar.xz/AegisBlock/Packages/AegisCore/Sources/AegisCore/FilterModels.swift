import Foundation

public struct FilterListSource: Codable, Identifiable, Sendable, Equatable {
  public var id: String
  public var name: String
  public var url: URL
  public var enabled: Bool
  public var isBuiltIn: Bool
  public init(id: String, name: String, url: URL, enabled: Bool = true, isBuiltIn: Bool = true) {
    self.id = id
    self.name = name
    self.url = url
    self.enabled = enabled
    self.isBuiltIn = isBuiltIn
  }

  public static let defaults: [FilterListSource] = [
    .init(
      id: "oisd-big", name: "OISD Big", url: URL(string: "https://big.oisd.nl")!, enabled: true),
    .init(
      id: "hagezi-pro", name: "HaGeZi Multi PRO",
      url: URL(
        string: "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/adblock/pro.txt")!,
      enabled: true),
    .init(
      id: "adguard-dns", name: "AdGuard DNS Filter",
      url: URL(string: "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt")!,
      enabled: false),
    .init(
      id: "stevenblack", name: "StevenBlack Unified",
      url: URL(string: "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts")!,
      enabled: false),
  ]
}

public struct FilterListMetadata: Codable, Sendable, Equatable {
  public var etag: String?
  public var lastModified: String?
  public var lastFetched: Date?
  public var entryCount = 0
  public var lastError: String?
  public init() {}
}

public struct FilterListState: Codable, Sendable, Equatable {
  public var sources: [FilterListSource] = FilterListSource.defaults
  public var metadata: [String: FilterListMetadata] = [:]
  public var userAllowlist: [String] = []
  public var userDenylist: [String] = []
  public var generation: UInt32 = 0
  public init() {}

  public static func load(from url: URL) -> FilterListState {
    guard let data = try? Data(contentsOf: url),
      var state = try? JSONDecoder().decode(Self.self, from: data)
    else { return .init() }
    let known = Set(state.sources.map(\.id))
    for source in FilterListSource.defaults where !known.contains(source.id) {
      state.sources.append(source)
    }
    let defs = Dictionary(uniqueKeysWithValues: FilterListSource.defaults.map { ($0.id, $0) })
    for i in state.sources.indices {
      if let d = defs[state.sources[i].id] {
        state.sources[i].name = d.name
        state.sources[i].url = d.url
        state.sources[i].isBuiltIn = true
      }
    }
    return state
  }

  public func save(to url: URL) throws {
    let encoder = JSONEncoder()
    encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
    try encoder.encode(self).write(to: url, options: .atomic)
  }
}
