import Foundation

public struct CompileStats: Sendable, Equatable {
  public var blockedEntryCount = 0
  public var userAllowEntryCount = 0
  public var userDenyEntryCount = 0
  public var skippedLines = 0
  public var perSourceCounts: [String: Int] = [:]
  public var generation: UInt32 = 0
  public init() {}
}

public enum BlocklistCompiler {
  @discardableResult
  public static func compile(state: inout FilterListState, paths: AppGroupPaths) throws
    -> CompileStats
  {
    var stats = CompileStats()
    var blocks = SeedRules.hashes
    var listAllows = Set<UInt64>()

    for source in state.sources where source.enabled {
      guard let data = try? Data(contentsOf: paths.cachedListURL(sourceID: source.id)),
        let text = String(data: data, encoding: .utf8)
      else { continue }
      let parsed = FilterListParser.parse(text)
      stats.skippedLines += parsed.skippedLines
      stats.perSourceCounts[source.id] = parsed.blockDomains.count
      for domain in parsed.blockDomains { blocks.insert(FNV1a.hash64(domain)) }
      for domain in parsed.allowDomains { listAllows.insert(FNV1a.hash64(domain)) }
      var meta = state.metadata[source.id] ?? .init()
      meta.entryCount = parsed.blockDomains.count
      state.metadata[source.id] = meta
    }
    blocks.subtract(listAllows)

    let allows = Set(state.userAllowlist.compactMap(DomainValidator.normalize).map(FNV1a.hash64))
    let denies = Set(state.userDenylist.compactMap(DomainValidator.normalize).map(FNV1a.hash64))
    state.generation &+= 1
    let generation = state.generation
    try CompiledBlocklist.write(hashes: blocks, generation: generation, to: paths.blocklistURL)
    try CompiledBlocklist.write(hashes: allows, generation: generation, to: paths.allowlistURL)
    try CompiledBlocklist.write(hashes: denies, generation: generation, to: paths.denylistURL)
    stats.blockedEntryCount = blocks.count
    stats.userAllowEntryCount = allows.count
    stats.userDenyEntryCount = denies.count
    stats.generation = generation
    try state.save(to: paths.stateURL)
    return stats
  }
}
