import Foundation

public struct ParsedUDPPacket: Sendable, Equatable {
  public let ipVersion: Int
  public let sourceAddress: [UInt8]
  public let destinationAddress: [UInt8]
  public let sourcePort: UInt16
  public let destinationPort: UInt16
  public let payload: [UInt8]
}

public enum PacketParser {
  public static func parseUDP(_ packet: Data) -> ParsedUDPPacket? {
    let b = [UInt8](packet)
    guard let first = b.first else { return nil }
    return first >> 4 == 4 ? ipv4(b) : (first >> 4 == 6 ? ipv6(b) : nil)
  }
  private static func ipv4(_ b: [UInt8]) -> ParsedUDPPacket? {
    guard b.count >= 28 else { return nil }
    let h = Int(b[0] & 0x0F) * 4
    guard h >= 20, b.count >= h + 8, b[9] == 17 else { return nil }
    let frag = UInt16(b[6]) << 8 | UInt16(b[7])
    guard frag & 0x3FFF == 0 else { return nil }
    let total = Int(b[2]) << 8 | Int(b[3])
    guard total >= h + 8, b.count >= total else { return nil }
    let udpLen = Int(b[h + 4]) << 8 | Int(b[h + 5])
    guard udpLen >= 8, h + udpLen <= total else { return nil }
    return .init(
      ipVersion: 4, sourceAddress: Array(b[12..<16]), destinationAddress: Array(b[16..<20]),
      sourcePort: u16(b, h), destinationPort: u16(b, h + 2),
      payload: Array(b[(h + 8)..<(h + udpLen)]))
  }
  private static func ipv6(_ b: [UInt8]) -> ParsedUDPPacket? {
    guard b.count >= 48, b[6] == 17 else { return nil }
    let payloadLen = Int(b[4]) << 8 | Int(b[5])
    guard payloadLen >= 8, b.count >= 40 + payloadLen else { return nil }
    let udpLen = Int(b[44]) << 8 | Int(b[45])
    guard udpLen >= 8, udpLen <= payloadLen else { return nil }
    return .init(
      ipVersion: 6, sourceAddress: Array(b[8..<24]), destinationAddress: Array(b[24..<40]),
      sourcePort: u16(b, 40), destinationPort: u16(b, 42), payload: Array(b[48..<(40 + udpLen)]))
  }
  private static func u16(_ b: [UInt8], _ i: Int) -> UInt16 { UInt16(b[i]) << 8 | UInt16(b[i + 1]) }
}

public enum InternetChecksum {
  public static func ipv4Header(_ bytes: [UInt8]) -> UInt16 { checksum(bytes) }
  public static func udp(ipVersion: Int, source: [UInt8], destination: [UInt8], segment: [UInt8])
    -> UInt16
  {
    var pseudo: [UInt8] = []
    pseudo += source
    pseudo += destination
    if ipVersion == 4 {
      pseudo += [0, 17, UInt8(segment.count >> 8), UInt8(segment.count & 255)]
    } else {
      let n = UInt32(segment.count)
      pseudo += [
        UInt8(n >> 24), UInt8((n >> 16) & 255), UInt8((n >> 8) & 255), UInt8(n & 255), 0, 0, 0, 17,
      ]
    }
    pseudo += segment
    let c = checksum(pseudo)
    return c == 0 ? 0xFFFF : c
  }
  private static func checksum(_ bytes: [UInt8]) -> UInt16 {
    var sum: UInt32 = 0
    var i = 0
    while i + 1 < bytes.count {
      sum += UInt32(bytes[i]) << 8 | UInt32(bytes[i + 1])
      i += 2
    }
    if i < bytes.count { sum += UInt32(bytes[i]) << 8 }
    while sum >> 16 != 0 { sum = (sum & 0xFFFF) + (sum >> 16) }
    return UInt16(~sum & 0xFFFF)
  }
}

public enum UDPReplyBuilder {
  public static func reply(to request: ParsedUDPPacket, payload: [UInt8]) -> Data? {
    request.ipVersion == 4
      ? ipv4(request, payload) : (request.ipVersion == 6 ? ipv6(request, payload) : nil)
  }
  private static func ipv4(_ r: ParsedUDPPacket, _ p: [UInt8]) -> Data? {
    let udp = 8 + p.count
    let total = 20 + udp
    guard total <= 65535, r.sourceAddress.count == 4, r.destinationAddress.count == 4 else {
      return nil
    }
    var h: [UInt8] = [0x45, 0, UInt8(total >> 8), UInt8(total & 255), 0, 0, 0x40, 0, 64, 17, 0, 0]
    h += r.destinationAddress + r.sourceAddress
    let c = InternetChecksum.ipv4Header(h)
    h[10] = UInt8(c >> 8)
    h[11] = UInt8(c & 255)
    return Data(h + segment(r, p, 4))
  }
  private static func ipv6(_ r: ParsedUDPPacket, _ p: [UInt8]) -> Data? {
    let n = 8 + p.count
    guard n <= 65535, r.sourceAddress.count == 16, r.destinationAddress.count == 16 else {
      return nil
    }
    var h: [UInt8] = [0x60, 0, 0, 0, UInt8(n >> 8), UInt8(n & 255), 17, 64]
    h += r.destinationAddress + r.sourceAddress
    return Data(h + segment(r, p, 6))
  }
  private static func segment(_ r: ParsedUDPPacket, _ p: [UInt8], _ v: Int) -> [UInt8] {
    let n = 8 + p.count
    var s: [UInt8] = [
      UInt8(r.destinationPort >> 8), UInt8(r.destinationPort & 255), UInt8(r.sourcePort >> 8),
      UInt8(r.sourcePort & 255), UInt8(n >> 8), UInt8(n & 255), 0, 0,
    ]
    s += p
    let c = InternetChecksum.udp(
      ipVersion: v, source: r.destinationAddress, destination: r.sourceAddress, segment: s)
    s[6] = UInt8(c >> 8)
    s[7] = UInt8(c & 255)
    return s
  }
}
