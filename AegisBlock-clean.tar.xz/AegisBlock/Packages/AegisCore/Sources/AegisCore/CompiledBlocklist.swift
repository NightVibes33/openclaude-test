import Foundation

public enum CompiledBlocklist {
  public static let magic = Array("AGB1".utf8)
  public static let formatVersion: UInt32 = 1
  public static let headerSize = 32

  public static func serialize(hashes: some Collection<UInt64>, generation: UInt32) -> Data {
    let sorted = Array(Set(hashes)).sorted()
    var data = Data(capacity: headerSize + sorted.count * 8)
    data.append(contentsOf: magic)
    appendU32(&data, formatVersion)
    appendU32(&data, UInt32(sorted.count))
    appendU32(&data, generation)
    data.append(contentsOf: [UInt8](repeating: 0, count: 16))
    for hash in sorted {
      var le = hash.littleEndian
      withUnsafeBytes(of: &le) { data.append(contentsOf: $0) }
    }
    return data
  }

  public static func write(hashes: some Collection<UInt64>, generation: UInt32, to url: URL) throws
  {
    try serialize(hashes: hashes, generation: generation).write(to: url, options: .atomic)
  }

  private static func appendU32(_ data: inout Data, _ value: UInt32) {
    var le = value.littleEndian
    withUnsafeBytes(of: &le) { data.append(contentsOf: $0) }
  }
}

public final class CompiledBlocklistView: @unchecked Sendable {
  public enum ReadError: Error { case badMagic, unsupportedVersion, corrupt }
  private let data: Data
  public let count: Int
  public let generation: UInt32

  public init(contentsOf url: URL) throws {
    let mapped = try Data(contentsOf: url, options: .alwaysMapped)
    guard mapped.count >= CompiledBlocklist.headerSize else { throw ReadError.corrupt }
    guard Array(mapped.prefix(4)) == CompiledBlocklist.magic else { throw ReadError.badMagic }
    guard Self.readU32(mapped, at: 4) == CompiledBlocklist.formatVersion else {
      throw ReadError.unsupportedVersion
    }
    let count = Int(Self.readU32(mapped, at: 8))
    guard mapped.count >= CompiledBlocklist.headerSize + count * 8 else { throw ReadError.corrupt }
    self.data = mapped
    self.count = count
    self.generation = Self.readU32(mapped, at: 12)
  }

  public func contains(_ hash: UInt64) -> Bool {
    guard count > 0 else { return false }
    return data.withUnsafeBytes { buffer in
      var low = 0
      var high = count - 1
      while low <= high {
        let mid = (low + high) / 2
        let offset = CompiledBlocklist.headerSize + mid * 8
        let value = UInt64(
          littleEndian: buffer.loadUnaligned(fromByteOffset: offset, as: UInt64.self))
        if value == hash { return true }
        if value < hash { low = mid + 1 } else { high = mid - 1 }
      }
      return false
    }
  }

  private static func readU32(_ data: Data, at offset: Int) -> UInt32 {
    data.withUnsafeBytes {
      UInt32(littleEndian: $0.loadUnaligned(fromByteOffset: offset, as: UInt32.self))
    }
  }
}
