import Foundation

public enum DNSWireError: Error { case truncated, malformed, notAQuery, unsupportedQuestionCount }

public enum DNSNameCodec {
  /// Decodes a DNS name and follows RFC 1035 compression pointers. `consumed`
  /// is the number of bytes occupied at the original offset, not the bytes
  /// traversed after following pointers.
  public static func decode(_ bytes: [UInt8], at offset: Int) throws -> (String, Int) {
    var labels: [String] = []
    var cursor = offset
    var consumed = 0
    var jumped = false
    var visited = Set<Int>()

    while true {
      guard cursor < bytes.count else { throw DNSWireError.truncated }
      guard visited.insert(cursor).inserted, visited.count <= 128 else {
        throw DNSWireError.malformed
      }

      let first = bytes[cursor]
      if first & 0xC0 == 0xC0 {
        guard cursor + 1 < bytes.count else { throw DNSWireError.truncated }
        let pointer = (Int(first & 0x3F) << 8) | Int(bytes[cursor + 1])
        guard pointer < bytes.count else { throw DNSWireError.malformed }
        if !jumped { consumed += 2 }
        cursor = pointer
        jumped = true
        continue
      }

      guard first & 0xC0 == 0 else { throw DNSWireError.malformed }
      cursor += 1
      if !jumped { consumed += 1 }
      let length = Int(first)
      if length == 0 { break }
      guard length <= 63, cursor + length <= bytes.count else { throw DNSWireError.malformed }
      guard let label = String(bytes: bytes[cursor..<(cursor + length)], encoding: .utf8) else {
        throw DNSWireError.malformed
      }
      labels.append(label.lowercased())
      cursor += length
      if !jumped { consumed += length }
    }
    return (labels.joined(separator: "."), consumed)
  }
}

public struct DNSQuery: Sendable {
  public let transactionID: UInt16
  public let flags: UInt16
  public let questionName: String
  public let rawQuestion: [UInt8]
  public let qtype: UInt16
  public let qclass: UInt16
  public let raw: Data
}

public enum DNSParser {
  public static func parseQuery(_ data: Data) throws -> DNSQuery {
    let b = [UInt8](data)
    guard b.count >= 12 else { throw DNSWireError.truncated }
    let flags = u16(b, 2)
    guard flags & 0x8000 == 0 else { throw DNSWireError.notAQuery }
    guard u16(b, 4) == 1 else { throw DNSWireError.unsupportedQuestionCount }
    let (name, len) = try DNSNameCodec.decode(b, at: 12)
    let q = 12 + len
    guard q + 4 <= b.count else { throw DNSWireError.truncated }
    return DNSQuery(
      transactionID: u16(b, 0), flags: flags, questionName: name,
      rawQuestion: Array(b[12..<(q + 4)]), qtype: u16(b, q), qclass: u16(b, q + 2), raw: data)
  }
  private static func u16(_ b: [UInt8], _ i: Int) -> UInt16 { UInt16(b[i]) << 8 | UInt16(b[i + 1]) }
}

/// Inspects an upstream DNS response for alias targets. This lets the local
/// blocker catch CNAME/DNAME/SVCB/HTTPS cloaking where a first-party-looking
/// hostname delegates resolution to a blocked ad or tracker domain.
public enum DNSResponseInspector {
  public static func aliasTargets(in data: Data) -> [String] {
    let bytes = [UInt8](data)
    guard bytes.count >= 12, (readU16(bytes, 2) & 0x8000) != 0 else { return [] }

    let questionCount = Int(readU16(bytes, 4))
    let recordCount = Int(readU16(bytes, 6)) + Int(readU16(bytes, 8)) + Int(readU16(bytes, 10))
    var cursor = 12

    do {
      for _ in 0..<questionCount {
        let (_, consumed) = try DNSNameCodec.decode(bytes, at: cursor)
        cursor += consumed
        guard cursor + 4 <= bytes.count else { return [] }
        cursor += 4
      }

      var aliases: [String] = []
      aliases.reserveCapacity(min(recordCount, 8))
      for _ in 0..<recordCount {
        let (_, consumed) = try DNSNameCodec.decode(bytes, at: cursor)
        cursor += consumed
        guard cursor + 10 <= bytes.count else { return aliases }
        let type = readU16(bytes, cursor)
        let rdLength = Int(readU16(bytes, cursor + 8))
        cursor += 10
        guard cursor + rdLength <= bytes.count else { return aliases }

        switch type {
        case 5, 39:  // CNAME, DNAME
          if let (name, _) = try? DNSNameCodec.decode(bytes, at: cursor), !name.isEmpty {
            aliases.append(name)
          }
        case 64, 65:  // SVCB, HTTPS: priority(2) + target name
          if rdLength >= 3, let (name, _) = try? DNSNameCodec.decode(bytes, at: cursor + 2),
            !name.isEmpty
          {
            aliases.append(name)
          }
        default:
          break
        }
        cursor += rdLength
      }
      return aliases
    } catch {
      return []
    }
  }

  private static func readU16(_ bytes: [UInt8], _ offset: Int) -> UInt16 {
    guard offset + 1 < bytes.count else { return 0 }
    return UInt16(bytes[offset]) << 8 | UInt16(bytes[offset + 1])
  }
}

public enum DNSResponseBuilder {
  public static func blocked(for query: DNSQuery, ttl: UInt32 = 60) -> Data {
    switch query.qtype {
    case 1: return build(query, rdata: [0, 0, 0, 0], ttl: ttl)
    case 28: return build(query, rdata: [UInt8](repeating: 0, count: 16), ttl: ttl)
    default: return build(query, rdata: nil, ttl: ttl)
    }
  }
  public static func servfail(for query: DNSQuery) -> Data {
    build(query, rdata: nil, ttl: 0, rcode: 2)
  }
  public static func truncated(for query: DNSQuery) -> Data {
    build(query, rdata: nil, ttl: 0, extraFlags: 0x0200)
  }

  private static func build(
    _ query: DNSQuery, rdata: [UInt8]?, ttl: UInt32, rcode: UInt16 = 0, extraFlags: UInt16 = 0
  ) -> Data {
    var out: [UInt8] = []
    var flags: UInt16 = 0x8080 | rcode | extraFlags
    flags |= query.flags & 0x0100
    append(&out, query.transactionID)
    append(&out, flags)
    append(&out, 1)
    append(&out, rdata == nil ? 0 : 1)
    append(&out, 0)
    append(&out, 0)
    out += query.rawQuestion
    if let rdata {
      out += [0xC0, 0x0C]
      append(&out, query.qtype)
      append(&out, query.qclass)
      out += [
        UInt8((ttl >> 24) & 255), UInt8((ttl >> 16) & 255), UInt8((ttl >> 8) & 255),
        UInt8(ttl & 255),
      ]
      append(&out, UInt16(rdata.count))
      out += rdata
    }
    return Data(out)
  }
  private static func append(_ out: inout [UInt8], _ v: UInt16) {
    out += [UInt8(v >> 8), UInt8(v & 255)]
  }
}
