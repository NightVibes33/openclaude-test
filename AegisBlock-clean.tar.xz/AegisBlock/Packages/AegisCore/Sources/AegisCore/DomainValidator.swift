import Foundation

public enum DomainValidator {
  public static func normalize(_ raw: String) -> String? {
    var value = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    while value.hasSuffix(".") { value.removeLast() }
    guard value.count >= 3, value.count <= 253, value.contains(".") else { return nil }

    let labels = value.split(separator: ".", omittingEmptySubsequences: false)
    guard labels.count >= 2 else { return nil }
    for label in labels {
      guard !label.isEmpty, label.count <= 63 else { return nil }
      guard label.first != "-", label.last != "-" else { return nil }
      for scalar in label.unicodeScalars {
        switch scalar {
        case "a"..."z", "0"..."9", "-", "_": continue
        default: return nil
        }
      }
    }
    return value
  }

  public static func suffixes(of normalizedDomain: String) -> [Substring] {
    let labels = normalizedDomain.split(separator: ".")
    guard labels.count >= 2 else { return [] }
    return (0..<(labels.count - 1)).map { labels[$0...].joined(separator: ".")[...] }
  }
}
