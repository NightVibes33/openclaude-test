import Foundation

public enum RuntimeIdentity {
  private static let extensionSuffixes = [
    ".tunnel", ".advanced", ".widgets",
    ".blocker1", ".blocker2", ".blocker3", ".blocker4", ".blocker5",
  ]

  public static func parentApplicationBundleID(for bundle: Bundle = .main) -> String? {
    parentApplicationBundleID(from: bundle.bundleIdentifier)
  }

  static func parentApplicationBundleID(from bundleIdentifier: String?) -> String? {
    guard var identifier = bundleIdentifier, !identifier.isEmpty else { return nil }
    if let suffix = extensionSuffixes.first(where: { identifier.hasSuffix($0) }) {
      identifier.removeLast(suffix.count)
    }
    return identifier.isEmpty ? nil : identifier
  }

  public static func appGroupCandidates(for bundle: Bundle = .main) -> [String] {
    var candidates: [String] = []

    // Prefer the runtime bundle family. Sideloading tools can rewrite the app
    // and extension identifiers, and commonly rewrite the App Group entitlement
    // to match that family as well.
    if let parentID = parentApplicationBundleID(for: bundle) {
      candidates.append("group.\(parentID)")
    }

    if let configured = bundle.object(forInfoDictionaryKey: "AppGroupID") as? String,
      !configured.isEmpty, !candidates.contains(configured)
    {
      candidates.append(configured)
    }

    return candidates
  }

  public static func availableAppGroupID(for bundle: Bundle = .main) -> String? {
    #if canImport(Darwin)
      return appGroupCandidates(for: bundle).first {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: $0) != nil
      }
    #else
      return nil
    #endif
  }

  public static func sharedPaths(for bundle: Bundle = .main) -> AppGroupPaths {
    #if canImport(Darwin)
      if let groupID = availableAppGroupID(for: bundle), let paths = AppGroupPaths(groupID: groupID) {
        return paths
      }
    #endif

    // Never terminate at launch because a sideload signer could not preserve
    // the App Group entitlement. The host app remains usable with sandbox-local
    // state; features that truly require cross-process sharing can report that
    // capability as unavailable instead of crashing.
    let root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)
      .first?
      .appendingPathComponent("AegisBlock", isDirectory: true)
      ?? FileManager.default.temporaryDirectory.appendingPathComponent("AegisBlock", isDirectory: true)
    return AppGroupPaths(containerURL: root)
  }

  public static func sharedSettings(for bundle: Bundle = .main) -> SharedSettings {
    #if canImport(Darwin)
      if let groupID = availableAppGroupID(for: bundle), let settings = SharedSettings(groupID: groupID) {
        return settings
      }
    #endif
    return SharedSettings(defaults: .standard)
  }

  public static func tunnelBundleIdentifier(for appBundle: Bundle = .main) -> String {
    if let parentID = parentApplicationBundleID(for: appBundle) {
      return parentID + ".tunnel"
    }
    return appBundle.object(forInfoDictionaryKey: "TunnelBundleID") as? String
      ?? "com.nightvibes33.aegisblock.tunnel"
  }

  public static func blockerBundleIdentifiers(for appBundle: Bundle = .main) -> [String] {
    if let parentID = parentApplicationBundleID(for: appBundle) {
      return (1...5).map { "\(parentID).blocker\($0)" }
    }
    return (1...5).map { "com.nightvibes33.aegisblock.blocker\($0)" }
  }
}
