import Foundation

public struct ParsedFilterList: Sendable, Equatable {
  public var blockDomains: [String] = []
  public var allowDomains: [String] = []
  public var totalLines = 0
  public var skippedLines = 0
  public init() {}
}

public enum FilterListParser {
  private static let sinkAddresses: Set<Substring> = [
    "0.0.0.0", "127.0.0.1", "::", "::1", "255.255.255.255",
  ]

  public static func parse(_ text: String) -> ParsedFilterList {
    var result = ParsedFilterList()
    text.enumerateLines { raw, _ in parseLine(raw, into: &result) }
    return result
  }

  private static func parseLine(_ raw: String, into result: inout ParsedFilterList) {
    result.totalLines += 1
    let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !line.isEmpty, !line.hasPrefix("!"), !line.hasPrefix("#"), !line.hasPrefix("[") else {
      return
    }

    if line.contains("##") || line.contains("#@#") || line.contains("#?#") || line.contains("#$#") {
      result.skippedLines += 1
      return
    }

    if line.hasPrefix("@@||") {
      if let domain = adblockDomain(line.dropFirst(4), permitModifiers: true) {
        result.allowDomains.append(domain)
      } else {
        result.skippedLines += 1
      }
      return
    }

    if line.hasPrefix("||") {
      if let domain = adblockDomain(line.dropFirst(2), permitModifiers: true) {
        result.blockDomains.append(domain)
      } else {
        result.skippedLines += 1
      }
      return
    }

    let tokens = line.split(whereSeparator: { $0 == " " || $0 == "\t" })
    if let first = tokens.first, sinkAddresses.contains(first) {
      for token in tokens.dropFirst() {
        if token.hasPrefix("#") { break }
        if let domain = DomainValidator.normalize(String(token)), domain != "localhost.localdomain"
        {
          result.blockDomains.append(domain)
        }
      }
      return
    }

    let bare = String(line.split(separator: "#", maxSplits: 1, omittingEmptySubsequences: false)[0])
    if let domain = DomainValidator.normalize(bare) {
      result.blockDomains.append(domain)
    } else {
      result.skippedLines += 1
    }
  }

  private static func adblockDomain(_ remainder: Substring, permitModifiers: Bool) -> String? {
    var end = remainder.endIndex
    if let caret = remainder.firstIndex(of: "^") { end = min(end, caret) }
    if let slash = remainder.firstIndex(of: "/") { end = min(end, slash) }
    if let dollar = remainder.firstIndex(of: "$") { end = min(end, dollar) }
    let part = remainder[..<end]
    guard !part.contains("*"), !part.contains("|") else { return nil }
    return DomainValidator.normalize(String(part))
  }
}
