// swift-tools-version: 6.2
import PackageDescription

let package = Package(
    name: "AegisCore",
    platforms: [.iOS(.v18), .macOS(.v15)],
    products: [
        .library(name: "AegisCore", targets: ["AegisCore"]),
        .library(name: "AegisTunnelKit", targets: ["AegisTunnelKit"])
    ],
    targets: [
        .target(name: "AegisCore"),
        .target(name: "AegisTunnelKit", dependencies: ["AegisCore"]),
        .testTarget(name: "AegisCoreTests", dependencies: ["AegisCore"])
    ],
    swiftLanguageModes: [.v6]
)
