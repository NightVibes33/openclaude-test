import AegisCore
import AppIntents
import SwiftUI
import WidgetKit

private var sharedSettings: SharedSettings { RuntimeIdentity.sharedSettings(for: Bundle.main) }

struct PauseAegisIntent: AppIntent {
  static let title: LocalizedStringResource = "Pause AegisBlock"
  @Parameter(title: "Minutes", default: 15) var minutes: Int
  func perform() async throws -> some IntentResult {
    sharedSettings.pausedUntil = Date(timeIntervalSinceNow: Double(max(1, minutes)) * 60)
    return .result()
  }
}

struct ResumeAegisIntent: AppIntent {
  static let title: LocalizedStringResource = "Resume AegisBlock"
  func perform() async throws -> some IntentResult {
    sharedSettings.pausedUntil = nil
    return .result()
  }
}

struct Entry: TimelineEntry {
  let date: Date
  let active: Bool
  let paused: Bool
}
struct Provider: TimelineProvider {
  func placeholder(in context: Context) -> Entry { .init(date: .now, active: true, paused: false) }
  func getSnapshot(in context: Context, completion: @escaping (Entry) -> Void) {
    completion(current())
  }
  func getTimeline(in context: Context, completion: @escaping (Timeline<Entry>) -> Void) {
    completion(Timeline(entries: [current()], policy: .after(Date(timeIntervalSinceNow: 300))))
  }
  private func current() -> Entry {
    let s = sharedSettings
    return .init(date: .now, active: s.protectionActive, paused: s.pausedUntil != nil)
  }
}
struct StatusWidget: Widget {
  let kind = "AegisStatus"
  var body: some WidgetConfiguration {
    StaticConfiguration(kind: kind, provider: Provider()) { e in
      VStack(alignment: .leading) {
        Image(systemName: e.active && !e.paused ? "shield.fill" : "shield.slash")
        Text(e.paused ? "Paused" : (e.active ? "Protected" : "Off")).font(.headline)
      }.containerBackground(.fill.tertiary, for: .widget)
    }.configurationDisplayName("AegisBlock").description("Protection status at a glance.")
      .supportedFamilies([.systemSmall, .accessoryCircular])
  }
}
@main struct AegisWidgetBundle: WidgetBundle { var body: some Widget { StatusWidget() } }
