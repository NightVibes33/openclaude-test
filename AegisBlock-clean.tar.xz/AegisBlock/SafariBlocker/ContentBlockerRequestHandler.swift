import Foundation
import SafariServices

final class ContentBlockerRequestHandler: NSObject, NSExtensionRequestHandling {
  func beginRequest(with context: NSExtensionContext) {
    let index =
      (Bundle.main.object(forInfoDictionaryKey: "RuleShardIndex") as? NSNumber)?.intValue ?? Int(
        Bundle.main.object(forInfoDictionaryKey: "RuleShardIndex") as? String ?? "1") ?? 1

    let shared = resolvedAppGroupID().flatMap {
      FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: $0)?
        .appendingPathComponent("safari/shard-\(index).json")
    }
    let fallback = Bundle.main.url(forResource: "fallback", withExtension: "json")
    guard
      let url = (shared.flatMap { FileManager.default.fileExists(atPath: $0.path) ? $0 : nil })
        ?? fallback,
      let provider = NSItemProvider(contentsOf: url)
    else {
      context.cancelRequest(withError: NSError(domain: "AegisBlock", code: 1))
      return
    }
    let item = NSExtensionItem()
    item.attachments = [provider]
    context.completeRequest(returningItems: [item], completionHandler: nil)
  }

  private func resolvedAppGroupID() -> String? {
    var candidates: [String] = []
    if var parentID = Bundle.main.bundleIdentifier {
      for suffix in [".blocker1", ".blocker2", ".blocker3", ".blocker4", ".blocker5"]
      where parentID.hasSuffix(suffix) {
        parentID.removeLast(suffix.count)
        break
      }
      candidates.append("group.\(parentID)")
    }
    if let configured = Bundle.main.object(forInfoDictionaryKey: "AppGroupID") as? String,
      !configured.isEmpty, !candidates.contains(configured)
    {
      candidates.append(configured)
    }
    return candidates.first {
      FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: $0) != nil
    }
  }
}
