import SwiftUI

extension View {
  @ViewBuilder
  func aegisSurface(cornerRadius: CGFloat = 20) -> some View {
    if #available(iOS 26.0, *) {
      self.glassEffect(in: .rect(cornerRadius: cornerRadius))
    } else {
      self.background(
        .regularMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
    }
  }
}
