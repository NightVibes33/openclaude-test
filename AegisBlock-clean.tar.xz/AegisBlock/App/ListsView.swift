import SwiftUI

struct ListsView: View {
  @Environment(ProtectionModel.self) private var model
  @Environment(TunnelController.self) private var tunnel
  @State private var allowInput = ""
  @State private var denyInput = ""

  var body: some View {
    @Bindable var model = model
    NavigationStack {
      Form {
        Section("DNS filter lists") {
          ForEach(model.filterState.sources) { source in
            Toggle(
              isOn: Binding(
                get: { source.enabled },
                set: { enabled in Task { await model.setSource(source.id, enabled: enabled) } })
            ) {
              VStack(alignment: .leading) {
                Text(source.name)
                if let count = model.filterState.metadata[source.id]?.entryCount, count > 0 {
                  Text("\(count.formatted()) domains").font(.caption).foregroundStyle(.secondary)
                }
              }
            }
          }
          Button("Apply changes") { Task { await model.updateAll(tunnel: tunnel) } }.disabled(
            model.isUpdating)
        }

        Section("Always allow") {
          HStack {
            TextField("example.com", text: $allowInput).textInputAutocapitalization(.never)
              .autocorrectionDisabled()
            Button("Add") {
              model.addAllow(allowInput)
              allowInput = ""
            }
          }
          ForEach(model.filterState.userAllowlist, id: \.self) { Text($0) }.onDelete(
            perform: model.removeAllow)
        }

        Section("Always block") {
          HStack {
            TextField("ads.example.com", text: $denyInput).textInputAutocapitalization(.never)
              .autocorrectionDisabled()
            Button("Add") {
              model.addDeny(denyInput)
              denyInput = ""
            }
          }
          ForEach(model.filterState.userDenylist, id: \.self) { Text($0) }.onDelete(
            perform: model.removeDeny)
        }
      }
      .navigationTitle("Filters")
    }
  }
}
