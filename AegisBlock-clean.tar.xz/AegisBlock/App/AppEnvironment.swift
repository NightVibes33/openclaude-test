import AegisCore
import Foundation

enum AppEnvironment {
  static let appGroupID = RuntimeIdentity.availableAppGroupID()
  static let tunnelBundleID = RuntimeIdentity.tunnelBundleIdentifier()
  static let blockerBundleIDs = RuntimeIdentity.blockerBundleIdentifiers()
  static let paths = RuntimeIdentity.sharedPaths()
  static let settings = RuntimeIdentity.sharedSettings()
  static var hasSharedAppGroup: Bool { appGroupID != nil }
}
