import AegisCore
import Foundation

enum AppEnvironment {
  static let appGroupID =
    Bundle.main.object(forInfoDictionaryKey: "AppGroupID") as? String
    ?? "group.com.nightvibes33.aegisblock"
  static let tunnelBundleID =
    Bundle.main.object(forInfoDictionaryKey: "TunnelBundleID") as? String
    ?? "com.nightvibes33.aegisblock.tunnel"
  static let blockerBundleIDs: [String] = (1...5).map { "com.nightvibes33.aegisblock.blocker\($0)" }
  static let paths = AppGroupPaths(groupID: appGroupID)!
  static let settings = SharedSettings(groupID: appGroupID)!
}
