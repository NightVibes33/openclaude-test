import BackgroundTasks
import SwiftUI

@main
struct AegisBlockApp: App {
  @State private var tunnel = TunnelController()
  @State private var model = ProtectionModel()

  private static let refreshID = "com.nightvibes33.aegisblock.refresh"
  private static let processingID = "com.nightvibes33.aegisblock.rules"

  init() {
    BGTaskScheduler.shared.register(forTaskWithIdentifier: Self.refreshID, using: nil) { task in
      guard let refreshTask = task as? BGAppRefreshTask else {
        task.setTaskCompleted(success: false)
        return
      }
      Self.handleRefresh(refreshTask)
    }
    BGTaskScheduler.shared.register(forTaskWithIdentifier: Self.processingID, using: nil) { task in
      guard let processingTask = task as? BGProcessingTask else {
        task.setTaskCompleted(success: false)
        return
      }
      Self.handleProcessing(processingTask)
    }
    Self.scheduleBackgroundWork()
  }

  var body: some Scene {
    WindowGroup {
      RootView().environment(tunnel).environment(model)
    }
  }

  private static func handleRefresh(_ task: BGAppRefreshTask) {
    let work = Task {
      do {
        _ = try await FilterUpdateService().refreshAll()
        _ = await SafariBlockerReloader.reloadAll()
        task.setTaskCompleted(success: true)
      } catch {
        task.setTaskCompleted(success: false)
      }
      scheduleBackgroundWork()
    }
    task.expirationHandler = { work.cancel() }
  }

  private static func handleProcessing(_ task: BGProcessingTask) {
    let work = Task {
      do {
        _ = try await FilterUpdateService().refreshAll()
        _ = await SafariBlockerReloader.reloadAll()
        task.setTaskCompleted(success: true)
      } catch {
        task.setTaskCompleted(success: false)
      }
      scheduleBackgroundWork()
    }
    task.expirationHandler = { work.cancel() }
  }

  static func scheduleBackgroundWork() {
    let refresh = BGAppRefreshTaskRequest(identifier: refreshID)
    refresh.earliestBeginDate = Date(timeIntervalSinceNow: 6 * 60 * 60)
    try? BGTaskScheduler.shared.submit(refresh)

    let processing = BGProcessingTaskRequest(identifier: processingID)
    processing.requiresNetworkConnectivity = true
    processing.requiresExternalPower = false
    processing.earliestBeginDate = Date(timeIntervalSinceNow: 18 * 60 * 60)
    try? BGTaskScheduler.shared.submit(processing)
  }
}
