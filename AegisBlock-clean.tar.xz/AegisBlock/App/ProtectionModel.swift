import AegisCore
import Foundation
import Observation

@MainActor
@Observable
final class ProtectionModel {
  var isUpdating = false
  var updateStatus = "Ready"
  var ruleCount = 0
  var safariEnabledCount = 0
  var lastError: String?
  var filterState = FilterListState()
  let updater = FilterUpdateService()

  init() {
    try? AppEnvironment.paths.ensureDirectories()
    filterState = FilterListState.load(from: AppEnvironment.paths.stateURL)
    Task { await refreshSafariState() }
  }

  func updateAll(tunnel: TunnelController) async {
    isUpdating = true
    lastError = nil
    updateStatus = "Updating filters…"
    do {
      let result = try await updater.refreshAll()
      ruleCount = result.dnsRules
      updateStatus = "Reloading protection…"
      await tunnel.reloadRules()
      _ = await SafariBlockerReloader.reloadAll()
      await refreshSafariState()
      filterState = FilterListState.load(from: AppEnvironment.paths.stateURL)
      updateStatus = "Up to date"
    } catch {
      lastError = error.localizedDescription
      updateStatus = "Update failed"
    }
    isUpdating = false
  }

  func setSource(_ id: String, enabled: Bool) async {
    guard let i = filterState.sources.firstIndex(where: { $0.id == id }) else { return }
    filterState.sources[i].enabled = enabled
    do { try filterState.save(to: AppEnvironment.paths.stateURL) } catch {
      lastError = error.localizedDescription
    }
  }

  func addAllow(_ domain: String) {
    guard let d = DomainValidator.normalize(domain), !filterState.userAllowlist.contains(d) else {
      return
    }
    filterState.userAllowlist.append(d)
    saveState()
  }
  func removeAllow(at offsets: IndexSet) {
    for i in offsets.sorted(by: >) { filterState.userAllowlist.remove(at: i) }
    saveState()
  }
  func addDeny(_ domain: String) {
    guard let d = DomainValidator.normalize(domain), !filterState.userDenylist.contains(d) else {
      return
    }
    filterState.userDenylist.append(d)
    saveState()
  }
  func removeDeny(at offsets: IndexSet) {
    for i in offsets.sorted(by: >) { filterState.userDenylist.remove(at: i) }
    saveState()
  }

  func refreshSafariState() async {
    safariEnabledCount = await SafariBlockerReloader.enabledCount()
  }

  private func saveState() {
    do { try filterState.save(to: AppEnvironment.paths.stateURL) } catch {
      lastError = error.localizedDescription
    }
  }
}
