import AegisCore
import SwiftUI

struct DashboardView: View {
  @Environment(TunnelController.self) private var tunnel
  @Environment(ProtectionModel.self) private var model

  var body: some View {
    NavigationStack {
      ScrollView {
        VStack(spacing: 22) {
          shield
          status
          HStack(spacing: 12) {
            StatCard(
              title: "Blocked", value: tunnel.runtimeStats?.blockedQueries ?? 0, icon: "nosign")
            StatCard(
              title: "Queries", value: tunnel.runtimeStats?.totalQueries ?? 0, icon: "network")
            StatCard(
              title: "DNS rules",
              value: UInt64(tunnel.runtimeStats?.blocklistEntryCount ?? UInt64(model.ruleCount)),
              icon: "line.3.horizontal.decrease.circle")
          }
          safariCard
          updateCard
          if let error = tunnel.lastError ?? model.lastError {
            Label(error, systemImage: "exclamationmark.triangle.fill").font(.footnote)
              .foregroundStyle(.orange).padding()
          }
        }
        .frame(maxWidth: 680)
        .padding()
        .frame(maxWidth: .infinity)
      }
      .navigationTitle("AegisBlock")
      .task {
        if !FileManager.default.fileExists(atPath: AppEnvironment.paths.blocklistURL.path) {
          await model.updateAll(tunnel: tunnel)
        }
        while !Task.isCancelled {
          await tunnel.refreshStats()
          try? await Task.sleep(for: .seconds(2))
        }
      }
    }
  }

  private var shield: some View {
    Button {
      Task { await tunnel.toggle() }
    } label: {
      ZStack {
        Circle().fill(tunnel.isOn ? Color.green.opacity(0.16) : Color.secondary.opacity(0.12))
          .frame(width: 170, height: 170)
        Image(systemName: tunnel.isOn ? "shield.checkered" : "shield.slash").font(
          .system(size: 72, weight: .semibold)
        ).symbolRenderingMode(.hierarchical)
      }
    }
    .buttonStyle(.plain)
    .accessibilityLabel(tunnel.isOn ? "Disable protection" : "Enable protection")
  }

  private var status: some View {
    VStack(spacing: 6) {
      Text(
        tunnel.state == .connected
          ? "Protected" : tunnel.state == .connecting ? "Connecting…" : "Protection off"
      ).font(.title2.bold())
      Text("Safari + encrypted DNS filtering").foregroundStyle(.secondary)
      if tunnel.state == .connected {
        if let until = AppEnvironment.settings.pausedUntil {
          Button("Resume blocking") { Task { await tunnel.resume() } }.buttonStyle(
            .borderedProminent)
          Text("Paused until \(until.formatted(date: .omitted, time: .shortened))").font(.caption)
            .foregroundStyle(.secondary)
        } else {
          Menu("Pause") {
            Button("5 minutes") { Task { await tunnel.pause(minutes: 5) } }
            Button("15 minutes") { Task { await tunnel.pause(minutes: 15) } }
            Button("1 hour") { Task { await tunnel.pause(minutes: 60) } }
          }.buttonStyle(.bordered)
        }
      }
    }
  }

  private var safariCard: some View {
    HStack {
      Image(systemName: "safari.fill").font(.title2)
      VStack(alignment: .leading) {
        Text("Safari protection").font(.headline)
        Text("\(model.safariEnabledCount) of 5 native blocker shards enabled").font(.subheadline)
          .foregroundStyle(.secondary)
      }
      Spacer()
      Button("Check") { Task { await model.refreshSafariState() } }.buttonStyle(.bordered)
    }.padding().aegisSurface()
  }

  private var updateCard: some View {
    VStack(alignment: .leading, spacing: 12) {
      HStack {
        Text("Rule intelligence").font(.headline)
        Spacer()
        if model.isUpdating { ProgressView() }
      }
      Text(model.updateStatus).foregroundStyle(.secondary)
      Button("Update all filters") { Task { await model.updateAll(tunnel: tunnel) } }.buttonStyle(
        .borderedProminent
      ).disabled(model.isUpdating)
    }.padding().aegisSurface()
  }
}

private struct StatCard: View {
  let title: String
  let value: UInt64
  let icon: String
  var body: some View {
    VStack(alignment: .leading, spacing: 8) {
      Label(title, systemImage: icon).font(.caption).foregroundStyle(.secondary).lineLimit(1)
      Text(value.formatted(.number.notation(.compactName))).font(.title2.bold()).contentTransition(
        .numericText())
    }.frame(maxWidth: .infinity, alignment: .leading).padding().aegisSurface(cornerRadius: 18)
  }
}
