import AegisCore
import SwiftUI

struct SettingsView: View {
  @Environment(ProtectionModel.self) private var model
  @Environment(TunnelController.self) private var tunnel
  @State private var upstream = AppEnvironment.settings.upstream

  var body: some View {
    NavigationStack {
      Form {
        Section("Encrypted DNS") {
          Picker("Resolver", selection: $upstream) {
            ForEach(UpstreamConfig.presets) { Text($0.name).tag($0) }
          }.onChange(of: upstream) { _, new in Task { await tunnel.setUpstream(new) } }
          LabeledContent("Protocol", value: "DNS over HTTPS")
        }
        Section("Privacy") {
          LabeledContent("Analytics", value: "None")
          LabeledContent("Account", value: "Not required")
          LabeledContent("Filtering", value: "On device")
          Text(
            "DNS queries are evaluated locally. Allowed DNS queries are sent only to the resolver you choose."
          ).font(.footnote).foregroundStyle(.secondary)
        }
        Section("Safari") {
          LabeledContent("Blockers enabled", value: "\(model.safariEnabledCount) / 5")
          Text(
            "iOS requires Safari extensions to be enabled by the user. Enable all AegisBlock content blockers for maximum coverage."
          ).font(.footnote).foregroundStyle(.secondary)
        }
        Section("Updates") {
          LabeledContent(
            "DNS lists",
            value: AppEnvironment.settings.lastDNSUpdate?.formatted(
              date: .abbreviated, time: .shortened) ?? "Never")
          LabeledContent(
            "Safari rules",
            value: AppEnvironment.settings.lastSafariUpdate?.formatted(
              date: .abbreviated, time: .shortened) ?? "Never")
        }
      }.navigationTitle("Settings")
    }
  }
}
