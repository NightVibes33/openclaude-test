import SwiftUI

struct RootView: View {
  @State private var onboardingComplete = AppEnvironment.settings.onboardingComplete

  var body: some View {
    if onboardingComplete {
      TabView {
        Tab("Protection", systemImage: "shield.fill") { DashboardView() }
        Tab("Filters", systemImage: "line.3.horizontal.decrease.circle") { ListsView() }
        Tab("Settings", systemImage: "gearshape.fill") { SettingsView() }
      }
    } else {
      OnboardingView {
        AppEnvironment.settings.onboardingComplete = true
        withAnimation { onboardingComplete = true }
      }
    }
  }
}

private struct OnboardingView: View {
  let continueAction: () -> Void

  var body: some View {
    ScrollView {
      VStack(spacing: 24) {
        Image(systemName: "shield.lefthalf.filled")
          .font(.system(size: 72, weight: .semibold))
          .symbolRenderingMode(.hierarchical)
          .foregroundStyle(.blue)
          .accessibilityHidden(true)

        VStack(spacing: 8) {
          Text("AegisBlock")
            .font(.largeTitle.bold())
          Text("Private ad and tracker blocking on your iPhone and iPad.")
            .multilineTextAlignment(.center)
            .foregroundStyle(.secondary)
        }

        VStack(spacing: 12) {
          DisclosureRow(
            icon: "lock.shield",
            title: "Filtering stays on device",
            detail:
              "Blocklist matching, allowlists, denylists, and Safari rule application happen locally."
          )
          DisclosureRow(
            icon: "network",
            title: "No remote VPN traffic",
            detail:
              "The Network Extension captures DNS packets only. Normal app and web traffic is never routed through an AegisBlock server."
          )
          DisclosureRow(
            icon: "eye.slash",
            title: "No AegisBlock analytics",
            detail:
              "AegisBlock has no account, ad SDK, analytics SDK, or tracking SDK. Allowed DNS queries go only to the encrypted resolver you select."
          )
        }

        Button("Continue") { continueAction() }
          .buttonStyle(.borderedProminent)
          .controlSize(.large)
          .frame(maxWidth: .infinity)
          .accessibilityHint(
            "Opens the protection dashboard. iOS asks for VPN configuration permission only after you enable DNS protection."
          )

        Text(
          "When you turn on device-wide protection, iOS will ask permission to add an AegisBlock VPN configuration. This is the system interface used by the DNS-only Network Extension; it is not a remote VPN service."
        )
        .font(.footnote)
        .foregroundStyle(.secondary)
        .multilineTextAlignment(.center)
      }
      .frame(maxWidth: 640)
      .padding(24)
      .frame(maxWidth: .infinity)
    }
  }
}

private struct DisclosureRow: View {
  let icon: String
  let title: String
  let detail: String

  var body: some View {
    HStack(alignment: .top, spacing: 14) {
      Image(systemName: icon)
        .font(.title2)
        .frame(width: 32)
        .accessibilityHidden(true)
      VStack(alignment: .leading, spacing: 4) {
        Text(title).font(.headline)
        Text(detail).font(.subheadline).foregroundStyle(.secondary)
      }
      Spacer(minLength: 0)
    }
    .padding()
    .aegisSurface(cornerRadius: 18)
    .accessibilityElement(children: .combine)
  }
}
