import AegisCore
import AppIntents

struct PauseProtectionIntent: AppIntent {
  static let title: LocalizedStringResource = "Pause AegisBlock"
  static let description = IntentDescription("Temporarily allow all DNS requests.")
  @Parameter(title: "Minutes", default: 15, inclusiveRange: (1, 120)) var minutes: Int
  func perform() async throws -> some IntentResult & ProvidesDialog {
    AppEnvironment.settings.pausedUntil = Date(timeIntervalSinceNow: Double(minutes) * 60)
    return .result(dialog: "AegisBlock paused for \(minutes) minutes.")
  }
}

struct ResumeProtectionIntent: AppIntent {
  static let title: LocalizedStringResource = "Resume AegisBlock"
  func perform() async throws -> some IntentResult & ProvidesDialog {
    AppEnvironment.settings.pausedUntil = nil
    return .result(dialog: "AegisBlock resumed.")
  }
}

struct AegisShortcuts: AppShortcutsProvider {
  static var appShortcuts: [AppShortcut] {
    AppShortcut(
      intent: PauseProtectionIntent(), phrases: ["Pause \(.applicationName)"],
      shortTitle: "Pause blocking", systemImageName: "pause.shield")
    AppShortcut(
      intent: ResumeProtectionIntent(), phrases: ["Resume \(.applicationName)"],
      shortTitle: "Resume blocking", systemImageName: "shield.checkered")
  }
}
