import AegisCore
import Foundation
import SafariServices

actor FilterUpdateService {
  enum UpdateError: LocalizedError {
    case badResponse(URL)
    case invalidSafariRules(URL)
    case noSources
    var errorDescription: String? {
      switch self {
      case .badResponse(let url): "Bad response from \(url.host ?? url.absoluteString)"
      case .invalidSafariRules(let url): "Invalid Safari rules from \(url.lastPathComponent)"
      case .noSources: "No enabled DNS filter lists"
      }
    }
  }

  struct Result: Sendable {
    let dnsRules: Int
    let safariShards: Int
  }
  private let session: URLSession

  init() {
    let c = URLSessionConfiguration.ephemeral
    c.timeoutIntervalForRequest = 20
    c.timeoutIntervalForResource = 60
    c.waitsForConnectivity = true
    session = URLSession(configuration: c)
  }

  func refreshAll() async throws -> Result {
    async let dns = refreshDNS()
    async let safari = refreshSafari()
    let (dnsCount, safariCount) = try await (dns, safari)
    return Result(dnsRules: dnsCount, safariShards: safariCount)
  }

  @discardableResult
  func refreshDNS() async throws -> Int {
    let paths = AppEnvironment.paths
    try paths.ensureDirectories()
    var state = FilterListState.load(from: paths.stateURL)
    let enabled = state.sources.filter(\.enabled)
    guard !enabled.isEmpty else { throw UpdateError.noSources }

    for source in enabled {
      var request = URLRequest(url: source.url)
      if let meta = state.metadata[source.id] {
        if let etag = meta.etag { request.setValue(etag, forHTTPHeaderField: "If-None-Match") }
        if let modified = meta.lastModified {
          request.setValue(modified, forHTTPHeaderField: "If-Modified-Since")
        }
      }
      do {
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else {
          throw UpdateError.badResponse(source.url)
        }
        if http.statusCode != 304 {
          guard (200..<300).contains(http.statusCode) else {
            throw UpdateError.badResponse(source.url)
          }
          try data.write(to: paths.cachedListURL(sourceID: source.id), options: .atomic)
        }
        var meta = state.metadata[source.id] ?? .init()
        meta.etag = http.value(forHTTPHeaderField: "ETag") ?? meta.etag
        meta.lastModified = http.value(forHTTPHeaderField: "Last-Modified") ?? meta.lastModified
        meta.lastFetched = .now
        meta.lastError = nil
        state.metadata[source.id] = meta
      } catch {
        var meta = state.metadata[source.id] ?? .init()
        meta.lastError = error.localizedDescription
        state.metadata[source.id] = meta
        if !FileManager.default.fileExists(atPath: paths.cachedListURL(sourceID: source.id).path) {
          throw error
        }
      }
    }

    let stats = try BlocklistCompiler.compile(state: &state, paths: paths)
    AppEnvironment.settings.lastDNSUpdate = .now
    return stats.blockedEntryCount
  }

  @discardableResult
  func refreshSafari() async throws -> Int {
    let paths = AppEnvironment.paths
    try paths.ensureDirectories()
    let state = FilterListState.load(from: paths.stateURL)
    let baseURL = "https://github.com/bnema/ublock-webkit-filters/releases/latest/download"
    let manifestURL = URL(string: baseURL + "/manifest.json")!

    var combinedFiles = ["combined-part1.json", "combined-part2.json"]
    if let (data, response) = try? await session.data(from: manifestURL),
      let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
      let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
      let combined = object["combined"] as? [String: Any],
      let files = combined["files"] as? [String], !files.isEmpty
    {
      combinedFiles = files
    }

    var produced = 0
    for index in 1...5 {
      let outputURL = paths.safariShardURL(index: index)
      guard index <= combinedFiles.count else {
        try makeFallbackRules(state: state, shard: index).write(to: outputURL, options: .atomic)
        produced += 1
        continue
      }

      let fileName = combinedFiles[index - 1]
      let url = URL(string: baseURL + "/" + fileName)!
      do {
        let (data, response) = try await session.data(from: url)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
          throw UpdateError.badResponse(url)
        }
        guard let raw = try JSONSerialization.jsonObject(with: data) as? [[String: Any]] else {
          throw UpdateError.invalidSafariRules(url)
        }
        let augmented = augmentSafariRules(raw, state: state, customDeny: index == 5)
        let encoded = try JSONSerialization.data(withJSONObject: augmented)
        try encoded.write(to: outputURL, options: .atomic)
        produced += 1
      } catch {
        if FileManager.default.fileExists(atPath: outputURL.path) {
          produced += 1
          continue
        }
        try makeFallbackRules(state: state, shard: index).write(to: outputURL, options: .atomic)
        produced += 1
      }
    }
    AppEnvironment.settings.lastSafariUpdate = .now
    return produced
  }

  private func augmentSafariRules(
    _ rules: [[String: Any]], state: FilterListState, customDeny: Bool
  ) -> [[String: Any]] {
    // WebKit enforces 150,000 rules per content-blocker extension. Reserve
    // space for local overrides before appending them so an upstream shard
    // can never become unloadable after a user adds allow/deny entries.
    let safariRuleLimit = 150_000
    var localRules: [[String: Any]] = []

    if customDeny {
      for raw in state.userDenylist {
        guard let domain = DomainValidator.normalize(raw) else { continue }
        let escaped = NSRegularExpression.escapedPattern(for: domain)
        localRules.append([
          "trigger": ["url-filter": "^https?://([^/:]+\\.)?\(escaped)[/:]"],
          "action": ["type": "block"],
        ])
      }
    }
    for raw in state.userAllowlist {
      guard let domain = DomainValidator.normalize(raw) else { continue }
      localRules.append([
        "trigger": ["url-filter": ".*", "if-domain": ["*\(domain)"]],
        "action": ["type": "ignore-previous-rules"],
      ])
    }

    let localCount = min(localRules.count, safariRuleLimit)
    let baseCapacity = max(0, safariRuleLimit - localCount)
    var out = Array(rules.prefix(baseCapacity))
    out.append(contentsOf: localRules.prefix(localCount))
    return out
  }

  private func makeFallbackRules(state: FilterListState, shard: Int) throws -> Data {
    var rules: [[String: Any]] = [
      [
        "trigger": ["url-filter": "^https?://aegis-never-match[.]invalid/"],
        "action": ["type": "block"],
      ]
    ]
    if shard == 5 {
      let builtIns = [
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "app-measurement.com",
        "adnxs.com",
      ]
      for domain in builtIns {
        let escaped = NSRegularExpression.escapedPattern(for: domain)
        rules.append([
          "trigger": ["url-filter": "^https?://([^/:]+\\.)?\(escaped)[/:]"],
          "action": ["type": "block"],
        ])
      }
    }
    return try JSONSerialization.data(
      withJSONObject: augmentSafariRules(rules, state: state, customDeny: shard == 5))
  }
}

@MainActor
enum SafariBlockerReloader {
  static func reloadAll() async -> [String: Bool] {
    var result: [String: Bool] = [:]
    for id in AppEnvironment.blockerBundleIDs {
      let ok = await withCheckedContinuation { continuation in
        SFContentBlockerManager.reloadContentBlocker(withIdentifier: id) { error in
          continuation.resume(returning: error == nil)
        }
      }
      result[id] = ok
    }
    return result
  }

  static func enabledCount() async -> Int {
    var count = 0
    for id in AppEnvironment.blockerBundleIDs {
      let enabled = await withCheckedContinuation { continuation in
        SFContentBlockerManager.getStateOfContentBlocker(withIdentifier: id) { state, _ in
          continuation.resume(returning: state?.isEnabled == true)
        }
      }
      if enabled { count += 1 }
    }
    return count
  }
}
