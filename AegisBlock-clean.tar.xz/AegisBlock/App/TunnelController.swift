import AegisCore
import Foundation
import NetworkExtension
import Observation

@MainActor
@Observable
final class TunnelController {
  enum State: String {
    case unknown, notInstalled, disconnected, connecting, connected, disconnecting, permissionNeeded
  }
  private(set) var state: State = .unknown
  private(set) var lastError: String?
  private(set) var runtimeStats: TunnelRuntimeStats?
  private var manager: NETunnelProviderManager?
  private var observer: NSObjectProtocol?

  init() {
    observer = NotificationCenter.default.addObserver(
      forName: .NEVPNStatusDidChange, object: nil, queue: .main
    ) { [weak self] _ in
      Task { @MainActor in self?.syncStatus() }
    }
    Task { await refresh() }
  }

  var isOn: Bool { state == .connected || state == .connecting }

  func refresh() async {
    do {
      manager = try await NETunnelProviderManager.loadAllFromPreferences().first
      syncStatus()
    } catch { lastError = error.localizedDescription }
  }

  func toggle() async { isOn ? await disable() : await enable() }

  func enable() async {
    do {
      let manager = try await ensureManager()
      manager.isEnabled = true
      manager.isOnDemandEnabled = true
      manager.onDemandRules = [NEOnDemandRuleConnect()]
      try await manager.saveToPreferences()
      try await manager.loadFromPreferences()
      try manager.connection.startVPNTunnel()
      lastError = nil
    } catch let error as NEVPNError where error.code == .configurationReadWriteFailed {
      state = .permissionNeeded
      lastError = "VPN permission is required. Tap Allow when iOS asks to add the configuration."
    } catch { lastError = error.localizedDescription }
    syncStatus()
  }

  func disable() async {
    guard let manager else { return }
    do {
      manager.isOnDemandEnabled = false
      try await manager.saveToPreferences()
      manager.connection.stopVPNTunnel()
      AppEnvironment.settings.protectionActive = false
      lastError = nil
    } catch { lastError = error.localizedDescription }
    syncStatus()
  }

  func pause(minutes: Int) async {
    let date = Date(timeIntervalSinceNow: Double(minutes * 60))
    AppEnvironment.settings.pausedUntil = date
    _ = await send(.setPause(date))
  }

  func resume() async {
    AppEnvironment.settings.pausedUntil = nil
    _ = await send(.setPause(nil))
  }

  func reloadRules() async { _ = await send(.reloadRules) }

  func setUpstream(_ config: UpstreamConfig) async {
    AppEnvironment.settings.upstream = config
    _ = await send(.setUpstream(config))
  }

  func refreshStats() async {
    if case .stats(let stats)? = await send(.getStats) {
      runtimeStats = stats
    } else if let data = try? Data(contentsOf: AppEnvironment.paths.statsURL),
      let stats = try? JSONDecoder().decode(TunnelRuntimeStats.self, from: data)
    {
      runtimeStats = stats
    }
  }

  private func ensureManager() async throws -> NETunnelProviderManager {
    if let manager { return manager }
    let manager =
      try await NETunnelProviderManager.loadAllFromPreferences().first ?? NETunnelProviderManager()
    let proto =
      (manager.protocolConfiguration as? NETunnelProviderProtocol) ?? NETunnelProviderProtocol()
    proto.providerBundleIdentifier = AppEnvironment.tunnelBundleID
    proto.serverAddress = TunnelConstants.serverDescription
    manager.protocolConfiguration = proto
    manager.localizedDescription = "AegisBlock"
    self.manager = manager
    return manager
  }

  private func syncStatus() {
    guard let status = manager?.connection.status else {
      state = .notInstalled
      return
    }
    state =
      switch status {
      case .connected: .connected
      case .connecting, .reasserting: .connecting
      case .disconnecting: .disconnecting
      case .disconnected: .disconnected
      case .invalid: .notInstalled
      @unknown default: .unknown
      }
  }

  private func send(_ request: TunnelRequest) async -> TunnelResponse? {
    guard let session = manager?.connection as? NETunnelProviderSession,
      manager?.connection.status == .connected,
      let data = try? TunnelIPC.encode(request)
    else { return nil }
    return await withCheckedContinuation { continuation in
      do {
        try session.sendProviderMessage(data) { reply in
          continuation.resume(returning: reply.flatMap { try? TunnelIPC.decodeResponse($0) })
        }
      } catch { continuation.resume(returning: nil) }
    }
  }
}
