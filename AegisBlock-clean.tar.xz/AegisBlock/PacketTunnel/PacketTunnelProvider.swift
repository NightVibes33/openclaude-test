import AegisCore
import AegisTunnelKit
import Darwin
import NetworkExtension
import os

final class PacketTunnelProvider: NEPacketTunnelProvider, @unchecked Sendable {
  private static let log = Logger(subsystem: "com.nightvibes33.aegisblock", category: "tunnel")
  private var engine: DNSProxyEngine?
  private var paths: AppGroupPaths?
  private var settings: SharedSettings?
  private var maintenanceTask: Task<Void, Never>?

  override func startTunnel(
    options: [String: NSObject]? = nil,
    completionHandler: @escaping @Sendable (Error?) -> Void
  ) {
    do {
      guard let groupID = RuntimeIdentity.availableAppGroupID(for: Bundle.main),
        let paths = AppGroupPaths(groupID: groupID), let settings = SharedSettings(groupID: groupID)
      else {
        throw NSError(
          domain: "AegisBlock", code: 1,
          userInfo: [NSLocalizedDescriptionKey: "Shared App Group is unavailable for this signing profile"])
      }
      self.paths = paths
      self.settings = settings
      try paths.ensureDirectories()
      let matcher = Self.loadMatcher(paths)
      let upstream = DoHUpstream(url: settings.upstream.url)
      let engine = DNSProxyEngine(matcher: matcher, upstream: upstream, mtu: TunnelConstants.mtu)
      self.engine = engine

      let ns = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: TunnelConstants.dnsIPv4)
      let v4 = NEIPv4Settings(
        addresses: [TunnelConstants.tunnelIPv4], subnetMasks: [TunnelConstants.maskIPv4])
      v4.includedRoutes = [
        NEIPv4Route(destinationAddress: TunnelConstants.dnsIPv4, subnetMask: "255.255.255.255")
      ]
      ns.ipv4Settings = v4
      let v6 = NEIPv6Settings(
        addresses: [TunnelConstants.tunnelIPv6],
        networkPrefixLengths: [NSNumber(value: TunnelConstants.prefixIPv6)])
      v6.includedRoutes = [
        NEIPv6Route(destinationAddress: TunnelConstants.dnsIPv6, networkPrefixLength: 128)
      ]
      ns.ipv6Settings = v6
      let dns = NEDNSSettings(servers: [TunnelConstants.dnsIPv4, TunnelConstants.dnsIPv6])
      dns.matchDomains = [""]
      ns.dnsSettings = dns
      ns.mtu = NSNumber(value: TunnelConstants.mtu)

      Task.detached(priority: .userInitiated) { await engine.pause(until: settings.pausedUntil) }
      setTunnelNetworkSettings(ns) { [weak self] error in
        guard let self else {
          completionHandler(CancellationError())
          return
        }
        guard error == nil else {
          completionHandler(error)
          return
        }
        settings.protectionActive = true
        self.startPacketLoop()
        self.startMaintenance()
        Self.log.info("AegisBlock DNS tunnel started with \(matcher.blockedEntryCount) entries")
        completionHandler(nil)
      }
    } catch {
      completionHandler(error)
    }
  }

  override func stopTunnel(
    with reason: NEProviderStopReason,
    completionHandler: @escaping @Sendable () -> Void
  ) {
    maintenanceTask?.cancel()
    settings?.protectionActive = false
    let engine = self.engine
    let paths = self.paths
    self.engine = nil
    guard let engine, let paths else {
      completionHandler()
      return
    }
    Task.detached(priority: .utility) {
      if let data = try? JSONEncoder().encode(await engine.stats()) {
        try? data.write(to: paths.statsURL, options: .atomic)
      }
      completionHandler()
    }
  }

  override func handleAppMessage(_ messageData: Data) async -> Data? {
    guard let engine, let request = try? TunnelIPC.decodeRequest(messageData) else { return nil }
    let response: TunnelResponse
    switch request {
    case .ping: response = .ok
    case .reloadRules:
      if let paths {
        await engine.reload(Self.loadMatcher(paths))
        response = .ok
      } else {
        response = .failure("No shared container")
      }
    case .getStats: response = .stats(await engine.stats())
    case .setPause(let date):
      await engine.pause(until: date)
      settings?.pausedUntil = date
      response = .ok
    case .setUpstream(let config):
      await engine.setUpstream(DoHUpstream(url: config.url))
      settings?.upstream = config
      response = .ok
    }
    return try? TunnelIPC.encode(response)
  }

  private static func loadMatcher(_ paths: AppGroupPaths) -> DomainMatcher {
    DomainMatcher(
      blocklist: try? CompiledBlocklistView(contentsOf: paths.blocklistURL),
      allowlist: try? CompiledBlocklistView(contentsOf: paths.allowlistURL),
      denylist: try? CompiledBlocklistView(contentsOf: paths.denylistURL))
  }

  private final class PacketFlowBox: @unchecked Sendable {
    let flow: NEPacketTunnelFlow

    init(_ flow: NEPacketTunnelFlow) {
      self.flow = flow
    }

    func write(_ packet: Data) {
      let family = ((packet.first ?? 0) >> 4) == 6 ? AF_INET6 : AF_INET
      flow.writePackets([packet], withProtocols: [NSNumber(value: family)])
    }
  }

  private func startPacketLoop() {
    guard let engine else { return }
    let flow = PacketFlowBox(packetFlow)
    packetFlow.readPackets { [weak self, engine, flow] packets, _ in
      guard let self else { return }
      for incoming in packets {
        let packet = Data(incoming)
        Task.detached(priority: .userInitiated) { [engine, flow, packet] in
          guard let reply = await engine.handlePacket(packet) else { return }
          flow.write(reply)
        }
      }
      self.startPacketLoop()
    }
  }

  private func startMaintenance() {
    guard let engine, let paths, let settings else { return }
    maintenanceTask = Task.detached(priority: .utility) { [engine, paths, settings] in
      var generation: UInt32?
      while !Task.isCancelled {
        try? await Task.sleep(for: .seconds(2))
        if Task.isCancelled { return }
        await engine.pause(until: settings.pausedUntil)
        if let data = try? JSONEncoder().encode(await engine.stats()) {
          try? data.write(to: paths.statsURL, options: .atomic)
        }
        if let view = try? CompiledBlocklistView(contentsOf: paths.blocklistURL),
          view.generation != generation
        {
          generation = view.generation
          await engine.reload(Self.loadMatcher(paths))
        }
      }
    }
  }
}
